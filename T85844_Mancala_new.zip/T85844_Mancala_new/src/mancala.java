import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;


public class mancala {

	
	int p0 = 0;//"011"
	Map<Integer,int[]> solutions = new HashMap<>();

	int orig[] = new int[]{1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1};




	public void setOrig(int[] orig) {
		this.orig = orig;
	}



	Queue<int[]> allArray = new LinkedList<>();
	
	public static List<int[]> readInput(String filename){
		List<int[]> retlist = new LinkedList<>();
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);   
			 String line = br.readLine();   
			 while (line != null) {   
			      String[] items = line.split(" ");
			      if(items.length > 2){
			    	  int[] n = new int[items.length];
			    	  for(int i=0;i<items.length;i++){
			    		  n[i] = Integer.parseInt(items[i]);
			    	  }
			    	  retlist.add(n);
			      }
			      line = br.readLine();   
			  }   
			  br.close();   
			  fr.close(); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		return retlist;

	}
	
	public static void writeTxt(String content){
		try {
			FileWriter fw = new FileWriter("OutputMancala.txt");
			fw.write(content);
			fw.flush();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void start(){
		allArray.add(orig);
		while(allArray.size() != 0){
			int[] head = allArray.poll();
			transform(head);
		}

	}
	
	
	public int getResult(){
		int min = Integer.MAX_VALUE;
		for(Integer key:solutions.keySet()){
			if(key < min){
				min = key;
			}
		}
		return min;
	}
	
	
	public void transform(int[] original){
		if(!isTransformed(original)){
			int count = 0;
			for(int i=0;i<original.length;i++){
				count += original[i];				
			}
			solutions.put(count, original);
			return;
			
		}
		List<Map<Integer,Integer>> transMapList = findPatern(original);
		for(Map<Integer,Integer>  transMap:transMapList){
			for(Integer key:transMap.keySet()){
				int pos = key;
				int pattern = transMap.get(key);
				int[] transformed = original.clone();
				if(pattern == p0){
					transformed[pos] = 1;
					transformed[pos+1] = 0;
					transformed[pos+2] = 0;				
				}else{
					transformed[pos] = 1;
					transformed[pos-1] = 0;
					transformed[pos-2] = 0;	
				}

				
				allArray.offer(transformed);
				
			}
		}
		/*
		try {
			Thread.sleep(5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		
	}
	
	public boolean isTransformed(int[] n){
		List<Map<Integer,Integer>> transMapList = findPatern(n);
		int size = 0;
		for(Map<Integer,Integer>  transMap:transMapList){
			size += transMap.size();
		}
		return size != 0;
		
		
		
		
	}
	
	public List<Map<Integer,Integer>> findPatern(int[] n){
		List<Map<Integer,Integer>> retListmap = new LinkedList<>();
		
		Map<Integer,Integer> p0Map = new HashMap<>();
		for(int i=0;i<n.length-2;i++){
			if(n[i] == 0 && n[i+1] == 1 && n[i+2] == 1){
				
				p0Map.put(i, 0);
			}
		}
		Map<Integer,Integer> p1Map = new HashMap<>();
		for(int i=n.length-1; i>1;i--){
			if(n[i] == 0 && n[i-1] == 1 && n[i-2] == 1){
				p1Map.put(i, 1);
			}
		}
		retListmap.add(p0Map);
		retListmap.add(p1Map);
		return retListmap;
	}

	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long timeS = System.currentTimeMillis();
		List<int[]> inputlist = readInput("testMancala.txt"); 
		int result[] = new int[inputlist.size()];
		StringBuffer sbResult = new StringBuffer();
		for(int i=0;i<inputlist.size();i++){
			int[] orig = inputlist.get(i);
			mancala m = new mancala();
			m.setOrig(orig);
			m.start();
			result[i] = m.getResult();
			sbResult.append(""+result[i]+"\n");
		}
		writeTxt(sbResult.toString());
		long timeE = System.currentTimeMillis();
		System.out.println(  "time");
		System.out.println(  timeE - timeS );

	}

}
