import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;


public class islands {
	
	 class Point{
		
		private int row;
		public Point(int row, int col) {
			super();
			this.row = row;
			this.col = col;
		}
		public int getRow() {
			return row;
		}
		public void setRow(int row) {
			this.row = row;
		}
		public int getCol() {
			return col;
		}
		public void setCol(int col) {
			this.col = col;
		}
		private int col;
		
		public boolean equals(Point o){
			if(this.row == o.row && this.col == o.col){
				return true;
			}
			return false;
		}
		public String toString(){
			return "(" + row + "," + col + ")"; 
		}
	}
	List<List<Point>> currentIsLands = new LinkedList<>();
	
	char[][] input;
	
	
	
	public char[][] getInput() {
		return input;
	}


	public void setInput(char[][] input) {
		this.input = input;
	}


	public List<Point> getIsland(Point point){
		if(point == null)return null;
		List<Point> currentIsland = null;
		for(List<Point> points:currentIsLands){
			for(int i=0;i<points.size();i++){
				if(point.equals(points.get(i))){
					currentIsland = points;
					break;
				}
			}
		}
		return currentIsland;
	}
	
	
	public void addSinglePoint(Point point){
		List<Point> points = new LinkedList<>();
		points.add(point);
		currentIsLands.add(points);
	}
	
	
	public void processSinglePoint(Point point){
		if(currentIsLands.size() == 0){
			addSinglePoint(point);
		}else{
			Point upPoint = getUpPoint(point);
			Point leftPoint = getLeftPoint(point);
			
			List<Point> upPoints = getIsland(upPoint);
			List<Point> leftPoints = getIsland(leftPoint);
			if(upPoints == null){
				if(leftPoints == null){
					//System.out.println(point);
					addSinglePoint(point);
				}else{
					leftPoints.add(point);
				}
			}else{
				if(leftPoints == null){
					upPoints.add(point);
				}else{
					List<Point> newpoints = new LinkedList<>();
					newpoints.addAll(leftPoints);
					newpoints.addAll(upPoints);
					newpoints.add(point);
					currentIsLands.remove(leftPoints);
					currentIsLands.remove(upPoints);
					currentIsLands.add(newpoints);
				}
			}
		}
	}
	
	
	public static List<char[][]> readInput(String filename){
		List<char[][]> charslist = new LinkedList<>();
		try {
			
			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);   
			 String line = br.readLine();  
			 char[][] temp = null;
			 int row = 0;
			 int col = 0;
			 while (line != null) {
				 //System.out.println(line);
				 if(line.contains("#") || line.contains("-")){
					 
					 char[] lineschars = line.trim().toCharArray();
					 for(int i=0;i<lineschars.length;i++){
						 temp[row][i] = lineschars[i];
					 }
					 row++;
				 }else{
					 
					 String items[] = line.trim().split(" ");
					 if(items.length != 1){
						 row = Integer.parseInt(items[0]);
						 col = Integer.parseInt(items[1]);
						 temp = new char[row][col];
						 charslist.add(temp);
						 row = 0;
					 }
				 }
			      
			      line = br.readLine();   
			  }   
			  br.close();   
			  fr.close(); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		return charslist;
	}
	
	
	public void start(){
		for(int i=0;i<input.length;i++){
			for(int j = 0; j<input[0].length;j++){
				if(input[i][j] == '-'){
					this.processSinglePoint(new Point(i,j));
				}
			}
		}
		
		
		//System.out.println(currentIsLands.size());
	}
	
	public int getResult(){
		return currentIsLands.size();
	}
	
	
	
	public List<Point> getAdjacentNO(Point point){
		List<Point> adjacents = new LinkedList<>();
		adjacents.add(getUpPoint(point));
		adjacents.add(getLeftPoint(point));
		return adjacents;
	}
	public Point getLeftPoint(Point point){
		int row = point.row;
		int col = point.col;
		if(col == 0){
			return null;
		}else{
			return new Point(row,col-1);
		}		
	}
	
	public Point getUpPoint(Point point){
		int row = point.row;
		int col = point.col;
		if(row == 0){
			return null;
		}else{
			return new Point(row-1,col);
		}		
	}
	
	public static void writeTxt(String content){
		try {
			FileWriter fw = new FileWriter("OutputIslands.txt");
			fw.write(content);
			fw.flush();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args){

		long timeS = System.currentTimeMillis();

		StringBuffer sb = new StringBuffer();
		List<char[][]> charslist = readInput("testIslands.txt");
		//System.out.println(charslist.size());
		for(char[][] chars:charslist){			
			islands lands = new islands();
			lands.setInput(chars);
			lands.start();
			sb.append(""+lands.getResult()+"\n");
		}
		System.out.println(sb);
		writeTxt(sb.toString());
		long timeE = System.currentTimeMillis();
		System.out.println(  "time");
		System.out.println(  timeE - timeS );



	}
	
	
	
	
}
