import java.io.*;
import java.util.*;
import  java.util.regex.*;
import java.math.*;
import static java.lang.System.*;


public class balloon {

    int numP = 0;
    ArrayList<Integer> arrowList = new ArrayList<Integer>();




    public  List<ArrayList<Integer>> readInput(String filename){
        //read file
        List<ArrayList<Integer>> inputlist = new LinkedList<>();
        try {
            FileReader fr = new FileReader( filename);
            BufferedReader Br = new BufferedReader(fr);
            String line = Br.readLine(); //start from first line
            int counter = 0;
            while (line!= null){
                String[] items = line.split(" ");
                if(counter == 0){
                    numP = Integer.parseInt(items[0]);
                    counter ++;
                }
                else if(counter == 1 ){
                    counter++;
                }
                else {
                    counter ++;
                    ArrayList<Integer> n = new ArrayList<Integer>();
                    for(int i = 0; i < items.length; i ++){
                        n.add(Integer.parseInt(items[i]));
                    }
                    inputlist.add(n);
                }
                line = Br.readLine();
            }
            fr.close();
            Br.close();
        }
        catch(IOException e){
            System.out.println("file input is wrong!");
        }
        //end
        return inputlist;

    }

    public int ballowShooting( ArrayList<Integer> ballonList){
        arrowList =  new ArrayList<Integer>();
        arrowList.add( ballonList.get(0));
        while(ballonList.size() != 0 ){
            //add the first arrow
            for( int i = 0 ; i < ballonList.size(); i ++ ){
                int arrowInt  = arrowList.indexOf(ballonList.get(i));
                if( arrowInt != -1 ){
                    int element = arrowList.get(arrowInt);
                    arrowList.set( arrowInt, element -1 );
                    ballonList.remove(ballonList.get(i)); //remove the item from ballon list
                    i -- ;
                }
            }
            if(ballonList.size() != 0 ){
                arrowList.add( ballonList.get(0));
            }
        }
        return arrowList.size();
    }

    public static void writeTxt(String content){
        try {
            FileWriter fw = new FileWriter("OutputBalloon.txt");
            fw.write(content);
            fw.flush();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args){
        //read file
        long timeS = System.currentTimeMillis();
        balloon b = new balloon();
        List<ArrayList<Integer>> inputlist = b.readInput("testBalloons.txt");
        StringBuffer sbResult = new StringBuffer();
        int result[] = new int[b.numP];
        for(int i = 0 ; i < inputlist.size() ; i++ ){
            ArrayList<Integer> temp = inputlist.get(i);
            result[i] =  b.ballowShooting(temp);
            sbResult.append(""+result[i]+"\n");
        }
        writeTxt(sbResult.toString());

        long timeE = System.currentTimeMillis();
        System.out.println(  "time");
        System.out.println(  timeE - timeS );

    }


}



