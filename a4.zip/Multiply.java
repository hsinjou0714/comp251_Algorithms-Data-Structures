import java.util.*;
import java.io.*;

public class Multiply{

    private static int randomInt(int size) {
        Random rand = new Random();
        int maxval = (1 << size) - 1;
        return rand.nextInt(maxval + 1);
    }
    
    public static int[] naive(int size, int x, int y) {
        // YOUR CODE GOES HERE  (Note: Change return statement)
        int[] result = new int[2];
        if(size == 1 ){
            result[0] = x*y;
            result[1] = 1;
        }
        else{
            int m = (size +1 ) >>1;
            int a = x>> m;
            int b = x &((1<<m) - 1);
            int c = y >>m ;
            int d = y  &((1<<m) - 1);
            int[] ac = naive(m,a,c);
            int[] bd = naive(m,b,d);
            int[] bc = naive(m,b,c);
            int[] ad = naive(m,a,d);
            result[0] = ( ac[0] <<(2*m)) +(( bc[0] + ad[0]) <<m) + bd[0];
            result[1] =  ac[1] + bd[1] + bc[1] + ad[1] + 3*m ;

        }
        return result;


        /*int[] result = new int[2];
        //convert x and y to binary
        String x_string = Integer.toBinaryString(x);
        String y_string = Integer.toBinaryString(y);
        result =naiveMutiplication(x_string, y_string, size, 0);


        return result;
        */
    }
    /*
        private  static int[] naiveMutiplication(String x, String y, int size , int counter ){
        int[] result= new int[2];
        int yLenth = y.length();
        int xLenth = x.length();
        if( yLenth  < size){
            for (int i = 0 ; i < size - yLenth  ; i++){
                y = "0" + y;
            }
        }
        if(xLenth < size){
            for (int i = 0 ; i < size - xLenth ; i++){
                x = "0" + x;
            }
        }

        if(size == 0 ){
            result[0] = 0;
            result[1] = counter;
            return  result;
        }
        else if(size == 1 ){
            int sum = (x.charAt(0) - '0')*(y.charAt(0) - '0');
            //base case = 1
            counter = counter +1;
            result[1] = counter;
            result[0] = sum;
            return result;
        }
        else{
            int m1 = size/2; //first half
            int m2 = size - m1;


            //extract first and second half
            String a = x.substring(0, m1);
            String b = x.substring(m1, size);

            String c = y.substring(0,m1);
            String d = y.substring(m1,size);
            //the recursive call
            //cost = 3*m
            int[] etemp = naiveMutiplication(a,c,m1, counter);
            int e = etemp[0];
            int eCounter =  etemp[1];

            int[] ftemp = naiveMutiplication(b,d,m2, counter);
            int f = ftemp[0];
            int fCounter = ftemp[1];

            int[] gtemp = naiveMutiplication(c,b,m2, counter);
            int g = gtemp[0];
            int gCounter = gtemp[1];

            int[] htemp = naiveMutiplication(a,d,m2, counter);
            int h = htemp[0];
            int hCounter = htemp[1];
            //final mutiplication
            result[0] = e*(1<<(2*m2)) + (g  + h )*(1 << m2 ) + f;
            counter = eCounter +  fCounter + gCounter  + hCounter  +3*size;
            result[1] = counter;
            return result;

        }

    }*/


    public static int[] karatsuba(int size, int x, int y) {
        
        // YOUR CODE GOES HERE  (Note: Change return statement)
       int[] result = new int[2];
       if(size == 1 ){
           result[0] = x*y;
           result[1] = 1;
       }
       else{
           int m = (size +1 ) >>1;
           int x1 = x>> m;
           int x2 = x &((1<<m) - 1);
           int y1 = y >>m ;
           int y2 = y  &((1<<m) - 1);
           int[] ac = karatsuba(m,x1,y1);
           int[] bd = karatsuba(m,x2,y2);
           int[] substract = karatsuba(m,x1 - x2,y1 -y2);
           result[0] = ( ac[0] <<(2*m)) +((ac[0] + bd[0] - substract[0]) <<m ) + bd[0];
           result[1] = 6*m + ac[1] + bd[1] + substract[1];

       }
       return result;

        
    }
    /*

    private static int[] KBinMutiplication(String x, String y, int size, int counter ){
        int[] result= new int[2];

        int yLenth = y.length();
        int xLenth = x.length();
        if(yLenth < size ){
            for (int i = 0 ; i < size - yLenth  ; i++){
                y = "0" + y;
             }
        }
        if(xLenth < size) {
            for (int i = 0; i < size -  xLenth ; i++) {
                x = "0" + x;
            }
        }

        if(size == 0 ){
            result[0] = 0;
            result[1] = counter;
            return  result;
        }
        else if( size == 1 ){
            //base case =1
           int sum = (x.charAt(0) - '0')*(y.charAt(0) - '0');
           counter = counter +1;
           result[1] = counter;
           result[0] = sum;
           return result;
        }
        else{
            int m1 = size/2; //first half
            int m2 = size - m1;

            //extract first and second half
            //6*m
            String a = x.substring(0, m1);
            String b = x.substring(m1, size);

            String c = y.substring(0,m1);
            String d = y.substring(m1, size);


            //the recursive call
            int[] etemp = KBinMutiplication(a,c, m1, counter);
            int e = etemp[0];
            int ecounter = etemp[1];

            int[] ftemp = KBinMutiplication(b,d,m2, counter);
            int f = ftemp[0];
            int fcounter = ftemp[1];

            //in odd number m2 >m1
            String ab  = Stringsub(a,b,m2);
            String cd = Stringsub(c,d, m2);
            // binary to decimal by radix 2

            int numbera = Integer.parseInt(a, 2);
            int numberb = Integer.parseInt(b, 2);
            int numberc = Integer.parseInt(c, 2);
            int numberd = Integer.parseInt(d, 2);

            int sum = numbera  - numberb ;
            int sum2= numberc -  numberd;
            int resolve = 0;
            if(sum < 0 ){
                ab  = Stringsub(b,a,m2);
                resolve ++;
            }
            if(sum2 <0 ){
                cd = Stringsub(d,c,m2);
                resolve ++;
            }
            int resolveNgative = (int) Math.pow(-1, resolve);

            int[] gtemp = KBinMutiplication( ab ,cd , m2, counter ) ; //the size could be wrong
            int g = resolveNgative*(gtemp[0]) ;
            int gcounter = gtemp[1];

            //final mutiplication


            result[0] = e*(1<<(2*m2))  + ( e + f - g )*(1 << m2 ) + f;
            counter = gcounter  + ecounter + fcounter + 6*size;
            result[1] = counter;
             return result;
        }


    }


    private static String  Stringsub( String input0 , String input1 , int binsize ){

        // binary to decimal by radix 2
        int number0 = Integer.parseInt(input0, 2);
        int number1 = Integer.parseInt(input1, 2);

        int sum = number0 - number1;
        String Stringsum = Integer.toBinaryString(sum);
        if(Stringsum.length() < binsize){
            for (int i = 0 ; i < binsize - Stringsum.length() ; i++) {
                Stringsum = "0" + Stringsum;
            }
        }
        return Stringsum ; //returns the answer as a binary value;
    }*/



    public static void main(String[] args){

               // int[] resKaratsuba = karatsuba(3,7,6);
       /* int maxRound = 20;
        int maxIntBitSize = 16;
        for (int size=3; size<=maxIntBitSize; size++) {
            int sumOpNaive = 0;
            int sumOpKaratsuba = 0;
            for (int round=0; round<maxRound; round++) {
                int x = randomInt(size);
                int y = randomInt(size);
                int[] resNaive = naive(size,x,y);
                int[] resKaratsuba = karatsuba(size,x,y);

                sumOpNaive += resNaive[1];
                sumOpKaratsuba += resKaratsuba[1];
            }
            int avgOpNaive = sumOpNaive / maxRound;
            int avgOpKaratsuba = sumOpKaratsuba / maxRound;
            System.out.println(size + "," + avgOpNaive + "," + avgOpKaratsuba);
        }*/

       try{
            int maxRound = 20;
            int maxIntBitSize = 16;
            for (int size=1; size<=maxIntBitSize; size++) {
                int sumOpNaive = 0;
                int sumOpKaratsuba = 0;
                for (int round=0; round<maxRound; round++) {
                    int x = randomInt(size);
                    int y = randomInt(size);
                    int[] resNaive = naive(size,x,y);
                    int[] resKaratsuba = karatsuba(size,x,y);

                    if (resNaive[0] != resKaratsuba[0]) {
                        throw new Exception("Return values do not match! (x=" + x + "; y=" + y + "; Naive=" + resNaive[0] + "; Karatsuba=" + resKaratsuba[0] + ")");
                    }
                    
                    if (resNaive[0] != (x*y)) {
                        int myproduct = x*y;
                        throw new Exception("Evaluation is wrong! (x=" + x + "; y=" + y + "; Your result=" + resNaive[0] + "; True value=" + myproduct + ")");
                    }
                    
                    sumOpNaive += resNaive[1];
                    sumOpKaratsuba += resKaratsuba[1];
                }
                int avgOpNaive = sumOpNaive / maxRound;
                int avgOpKaratsuba = sumOpKaratsuba / maxRound;
                System.out.println(size + "," + avgOpNaive + "," + avgOpKaratsuba);
            }
        }
        catch (Exception e){
            System.out.println(e);
        }

   }
}
